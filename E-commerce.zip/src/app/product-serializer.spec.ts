import { ProductSerializer } from './product-serializer';

describe('ProductSerializer', () => {
  it('should create an instance', () => {
    expect(new ProductSerializer()).toBeTruthy();
  });
});
