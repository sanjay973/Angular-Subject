import { ModelViewLocator } from './model-view-locator';

describe('ModelViewLocator', () => {
  it('should create an instance', () => {
    expect(new ModelViewLocator()).toBeTruthy();
  });
});
